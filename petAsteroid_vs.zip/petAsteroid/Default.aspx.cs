﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PrimS.Telnet;
using System.Threading;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string hostname = "horizons.jpl.nasa.gov";
        int port = 6775;
        CancellationToken token = new CancellationToken();
        Client client = new Client(hostname, port, token);
        if(client.IsConnected)
            message.Text = "Client connected";
        else
            message.Text = "Client not connected";
    }
}